# Parte B - Proyecto Chocolate Doom

## Descripción

Este paquete contiene la versión mejorada de la Parte B del proyecto de bases de datos para Chocolate Doom.

La Parte B implementa el modelo lógico en PostgreSQL, crea tablas principales, tablas de staging, carga datos sintéticos, carga un instrumento UX, genera telemetría y agrega validaciones.

## Estructura

```text
parte_b_chocolate_doom_version_mejorada/
├── README.md
├── data/
│   └── sample_telemetry.tsv
└── sql/
    ├── 00_run_all.sql
    ├── 01_schema.sql
    ├── 02_staging.sql
    ├── 03_seed_data.sql
    ├── 04_load_ux.sql
    ├── 05_generate_telemetry.sql
    ├── 06_load_from_staging.sql
    ├── 07_validation_queries.sql
    └── 08_indexes.sql
```

## Orden de ejecución recomendado

Desde `psql`, ubicado en la carpeta raíz del proyecto:

```sql
\i sql/00_run_all.sql
```

El archivo `00_run_all.sql` ejecuta los scripts principales en orden.

## Descripción de archivos

### `01_schema.sql`

Crea las tablas principales del modelo relacional:

- `research_user`
- `player`
- `episode`
- `map`
- `sector`
- `game`
- `game_participant`
- `telemetry_event`
- `ux_instrument`
- `ux_item`
- `ux_response`
- `ux_response_item`

Incluye claves primarias, claves foráneas y restricciones de integridad.

### `02_staging.sql`

Crea las tablas para el proceso ETL:

- `staging_telemetry_raw`
- `etl_error_log`

La tabla staging recibe datos TSV en formato texto antes de transformarlos a las tablas finales.

### `03_seed_data.sql`

Inserta datos sintéticos base:

- 6 usuarios.
- 6 jugadores.
- 3 episodios.
- 3 mapas.
- 75 sectores.
- 3 partidas.
- 18 participaciones.

### `04_load_ux.sql`

Carga el instrumento UX PENS, sus ítems y respuestas sintéticas asociadas a los usuarios.

### `05_generate_telemetry.sql`

Genera telemetría sintética:

```text
3 partidas x 6 jugadores x 1200 tics = 21600 registros
```

### `06_load_from_staging.sql`

Contiene la versión mejorada del flujo ETL desde staging hacia `telemetry_event`.

Incluye validaciones para:

- Campos requeridos vacíos.
- Campos numéricos inválidos.
- Jugadores inexistentes.
- Episodios, mapas o sectores inexistentes.
- Duplicados por `game_id`, `player_id` y `tic`.

Los errores se registran en `etl_error_log`.

### `07_validation_queries.sql`

Contiene consultas para validar la carga de datos:

- Total de usuarios.
- Total de jugadores.
- Total de episodios.
- Total de sectores.
- Total de partidas.
- Total de participaciones.
- Total de eventos de telemetría.
- Respuestas UX cargadas.

### `08_indexes.sql`

Incluye índices para mejorar consultas frecuentes sobre telemetría, jugadores, partidas y sectores.

Este archivo es útil como avance para la Parte C, donde se analizará rendimiento con índices y consultas analíticas.

## Carga de archivo TSV de ejemplo

Para probar el flujo staging, primero se carga el archivo `data/sample_telemetry.tsv`:

```sql
COPY staging_telemetry_raw (
    game_code,
    player_nickname,
    tic,
    episode_code,
    map_code,
    sector_code,
    pos_x,
    pos_y,
    pos_z,
    angle,
    momentum_x,
    momentum_y,
    momentum_z,
    fov,
    health,
    armor,
    ammo
)
FROM '/ruta/absoluta/data/sample_telemetry.tsv'
WITH (
    FORMAT csv,
    DELIMITER E'\t',
    HEADER true
);
```

Luego se ejecuta:

```sql
\i sql/06_load_from_staging.sql
```

## Resultado esperado

Después de ejecutar `00_run_all.sql`, se espera tener:

- 6 usuarios.
- 6 jugadores.
- 3 episodios.
- 3 mapas.
- 75 sectores.
- 3 partidas.
- 18 participaciones.
- 21.600 registros de telemetría.
- Instrumento UX PENS cargado.
- Respuestas UX sintéticas.
- Índices creados para consultas frecuentes.

## Nota para sustentación

Esta entrega muestra la implementación física del modelo relacional diseñado en la Parte A. Además, propone un flujo ETL usando staging para cargar logs TSV, validar datos, registrar errores y transformar registros hacia la tabla final `telemetry_event`.
