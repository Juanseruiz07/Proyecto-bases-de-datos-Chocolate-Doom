-- Archivo: 06_load_from_staging.sql
-- Pipeline ETL: staging_telemetry_raw -> telemetry_event
-- Ejecutar después de cargar el TSV con \COPY en staging_telemetry_raw

-- Paso 1: registrar filas con campos obligatorios vacíos o nulos
INSERT INTO etl_error_log (raw_id, error_message, raw_payload)
SELECT
    raw_id,
    'campo obligatorio vacío o nulo',
    to_jsonb(staging_telemetry_raw)
FROM staging_telemetry_raw
WHERE game_code      IS NULL OR trim(game_code)      = ''
   OR player_nickname IS NULL OR trim(player_nickname) = ''
   OR tic            IS NULL OR trim(tic)             = ''
   OR pos_x          IS NULL OR trim(pos_x)           = ''
   OR pos_y          IS NULL OR trim(pos_y)           = ''
   OR pos_z          IS NULL OR trim(pos_z)           = ''
   OR health         IS NULL OR trim(health)          = '';

-- Paso 2: registrar filas con tipos inválidos (no numéricos)
INSERT INTO etl_error_log (raw_id, error_message, raw_payload)
SELECT
    raw_id,
    'valor no numérico en campo de tipo numérico',
    to_jsonb(staging_telemetry_raw)
FROM staging_telemetry_raw
WHERE NOT (tic    ~ '^\d+$')
   OR NOT (pos_x  ~ '^-?\d+(\.\d+)?$')
   OR NOT (pos_y  ~ '^-?\d+(\.\d+)?$')
   OR NOT (pos_z  ~ '^-?\d+(\.\d+)?$')
   OR NOT (health ~ '^\d+$');

-- Paso 3: registrar duplicados que ya existen en telemetry_event
-- antes de intentar insertarlos, para que quede trazabilidad
INSERT INTO etl_error_log (raw_id, error_message, raw_payload)
SELECT
    r.raw_id,
    'duplicado: (game_id, player_id, tic) ya existe en telemetry_event',
    to_jsonb(r)
FROM staging_telemetry_raw r
JOIN player p
    ON p.nickname = r.player_nickname
JOIN episode e
    ON e.episode_code = r.episode_code
JOIN map m
    ON m.episode_id = e.episode_id
   AND m.map_code   = r.map_code
JOIN game g
    ON g.map_id = m.map_id
WHERE r.tic ~ '^\d+$'
  AND EXISTS (
      SELECT 1 FROM telemetry_event te
      WHERE te.game_id   = g.game_id
        AND te.player_id = p.player_id
        AND te.tic       = r.tic::INTEGER
  );

-- Paso 4: registrar jugadores inexistentes en la base
INSERT INTO etl_error_log (raw_id, error_message, raw_payload)
SELECT
    r.raw_id,
    'jugador no registrado: ' || r.player_nickname,
    to_jsonb(r)
FROM staging_telemetry_raw r
LEFT JOIN player p ON p.nickname = r.player_nickname
WHERE p.player_id IS NULL;

-- Paso 5: cargar solo registros válidos y no duplicados
INSERT INTO telemetry_event (
    game_id, player_id, sector_id, tic,
    pos_x, pos_y, pos_z, angle,
    momentum_x, momentum_y, momentum_z,
    fov, health, armor, ammo
)
SELECT
    g.game_id,
    p.player_id,
    s.sector_id,
    r.tic::INTEGER,
    r.pos_x::NUMERIC,
    r.pos_y::NUMERIC,
    r.pos_z::NUMERIC,
    r.angle::NUMERIC,
    r.momentum_x::NUMERIC,
    r.momentum_y::NUMERIC,
    r.momentum_z::NUMERIC,
    r.fov::NUMERIC,
    r.health::INTEGER,
    r.armor::INTEGER,
    r.ammo::INTEGER
FROM staging_telemetry_raw r
JOIN player p
    ON p.nickname    = r.player_nickname
JOIN episode e
    ON e.episode_code = r.episode_code
JOIN map m
    ON m.episode_id  = e.episode_id
   AND m.map_code    = r.map_code
JOIN sector s
    ON s.map_id      = m.map_id
   AND s.sector_code = r.sector_code
JOIN game g
    ON g.map_id      = m.map_id
WHERE r.tic   ~ '^\d+$'
  AND r.pos_x ~ '^-?\d+(\.\d+)?$'
  AND r.pos_y ~ '^-?\d+(\.\d+)?$'
  AND r.pos_z ~ '^-?\d+(\.\d+)?$'
  AND r.health ~ '^\d+$'
  AND trim(r.player_nickname) != ''
ON CONFLICT (game_id, player_id, tic) DO NOTHING;
