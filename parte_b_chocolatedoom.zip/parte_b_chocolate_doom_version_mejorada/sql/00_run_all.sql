-- Archivo: 00_run_all.sql
-- Ejecuta toda la Parte B en orden desde psql
-- Uso: psql -d chocolate_doom -f sql/00_run_all.sql

\i sql/01_schema.sql
\i sql/02_staging.sql
\i sql/03_seed_data.sql
\i sql/04_load_ux.sql
\i sql/05_generate_telemetry.sql
\i sql/08_indexes.sql
\i sql/07_validation_queries.sql
