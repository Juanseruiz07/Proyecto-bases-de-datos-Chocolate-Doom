-- Archivo: 08_indexes.sql
-- Índices para telemetry_event, sector y game_participant
-- Ejecutar después de cargar datos (05_generate_telemetry.sql)

-- El índice más usado: recuperar la trayectoria completa de un jugador
-- en una partida ordenada por tic. Cubre la mayoría de las queries
-- analíticas de la Parte C.
CREATE INDEX IF NOT EXISTS idx_telemetry_trajectory
    ON telemetry_event (game_id, player_id, tic);

-- Permite filtrar eventos por ubicación en el mapa sin pasar por sector_id.
-- Útil para las queries de hotspot (Q5) y co-presencia en sector (Q6).
CREATE INDEX IF NOT EXISTS idx_telemetry_location
    ON telemetry_event (sector_id, game_id, tic);

-- Índice espacial sobre la posición 2D del jugador.
-- Necesario para calcular distancias de proximidad (Q2) de forma eficiente.
-- Requiere que pos_x y pos_y sean NUMERIC; el cast a POINT es implícito en
-- queries con operadores de distancia de PostGIS o con cálculo manual.
CREATE INDEX IF NOT EXISTS idx_telemetry_position
    ON telemetry_event USING btree (pos_x, pos_y);

-- Índice invertido en game_participant: permite buscar todas las partidas
-- de un jugador sin escanear la tabla completa. La PK ya cubre (game_id,
-- player_id), pero no (player_id, game_id).
CREATE INDEX IF NOT EXISTS idx_participant_player
    ON game_participant (player_id, game_id);
