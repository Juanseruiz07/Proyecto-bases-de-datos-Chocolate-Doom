-- =========================================================
-- Parte B - Proyecto Chocolate Doom
-- Archivo: 04_load_ux.sql
-- Objetivo: Poblar instrumento UX PENS y respuestas sintéticas
-- =========================================================

INSERT INTO ux_instrument (
    name,
    version,
    description
)
VALUES
(
    'PENS',
    '1.0',
    'Player Experience of Need Satisfaction instrument used to evaluate player experience in games'
);

INSERT INTO ux_item (
    instrument_id,
    item_code,
    question_text,
    dimension
)
VALUES
(1, 'PENS01', 'I felt competent while playing the game.', 'competence'),
(1, 'PENS02', 'I felt free to make decisions during the game.', 'autonomy'),
(1, 'PENS03', 'I felt connected with other players.', 'relatedness'),
(1, 'PENS04', 'The game controls were easy to understand.', 'intuitive_controls'),
(1, 'PENS05', 'I felt immersed in the game environment.', 'immersion');

INSERT INTO ux_response (
    user_id,
    instrument_id,
    response_date
)
SELECT
    user_id,
    1 AS instrument_id,
    CURRENT_TIMESTAMP
FROM research_user;

INSERT INTO ux_response_item (
    response_id,
    item_id,
    score
)
SELECT
    r.response_id,
    i.item_id,
    FLOOR(1 + random() * 5)::INTEGER AS score
FROM ux_response r
JOIN ux_item i 
    ON i.instrument_id = r.instrument_id;

UPDATE ux_response r
SET total_score = sub.average_score
FROM (
    SELECT
        response_id,
        AVG(score)::NUMERIC(8,2) AS average_score
    FROM ux_response_item
    GROUP BY response_id
) sub
WHERE r.response_id = sub.response_id;
