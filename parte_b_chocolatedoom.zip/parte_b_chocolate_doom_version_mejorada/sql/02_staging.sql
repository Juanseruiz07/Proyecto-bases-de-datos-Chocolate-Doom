-- =========================================================
-- Parte B - Proyecto Chocolate Doom
-- Archivo: 02_staging.sql
-- Objetivo: Crear tablas para ingesta TSV y log de errores ETL
-- =========================================================

DROP TABLE IF EXISTS staging_telemetry_raw CASCADE;
DROP TABLE IF EXISTS etl_error_log CASCADE;

CREATE TABLE staging_telemetry_raw (
    raw_id BIGSERIAL PRIMARY KEY,
    game_code TEXT,
    player_nickname TEXT,
    tic TEXT,
    episode_code TEXT,
    map_code TEXT,
    sector_code TEXT,
    pos_x TEXT,
    pos_y TEXT,
    pos_z TEXT,
    angle TEXT,
    momentum_x TEXT,
    momentum_y TEXT,
    momentum_z TEXT,
    fov TEXT,
    health TEXT,
    armor TEXT,
    ammo TEXT,
    loaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE etl_error_log (
    error_id BIGSERIAL PRIMARY KEY,
    raw_id BIGINT,
    error_message TEXT NOT NULL,
    raw_payload JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
