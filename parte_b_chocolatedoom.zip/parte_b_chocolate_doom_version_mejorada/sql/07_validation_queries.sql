-- =========================================================
-- Parte B - Proyecto Chocolate Doom
-- Archivo: 07_validation_queries.sql
-- Objetivo: Consultas para validar la carga de datos
-- =========================================================

SELECT COUNT(*) AS total_users
FROM research_user;

SELECT COUNT(*) AS total_players
FROM player;

SELECT COUNT(*) AS total_episodes
FROM episode;

SELECT COUNT(*) AS total_maps
FROM map;

SELECT COUNT(*) AS total_sectors
FROM sector;

SELECT COUNT(*) AS total_games
FROM game;

SELECT COUNT(*) AS total_participants
FROM game_participant;

SELECT COUNT(*) AS total_telemetry_events
FROM telemetry_event;

SELECT
    p.nickname,
    COUNT(*) AS total_events
FROM telemetry_event te
JOIN player p 
    ON p.player_id = te.player_id
GROUP BY p.nickname
ORDER BY total_events DESC;

SELECT
    g.game_id,
    m.map_code,
    COUNT(te.telemetry_id) AS total_events
FROM game g
JOIN map m 
    ON m.map_id = g.map_id
JOIN telemetry_event te 
    ON te.game_id = g.game_id
GROUP BY g.game_id, m.map_code
ORDER BY g.game_id;

SELECT
    u.anonymous_code,
    i.name AS instrument_name,
    r.total_score
FROM ux_response r
JOIN research_user u 
    ON u.user_id = r.user_id
JOIN ux_instrument i 
    ON i.instrument_id = r.instrument_id
ORDER BY u.anonymous_code;
