-- =========================================================
-- Parte B - Proyecto Chocolate Doom
-- Archivo: 03_seed_data.sql
-- Objetivo: Insertar usuarios, jugadores, episodios, mapas,
-- sectores, partidas y participantes
-- =========================================================

INSERT INTO research_user (
    anonymous_code,
    age,
    gender,
    experience_level,
    consent_accepted,
    consent_date
)
VALUES
('U001', 20, 'male', 'intermediate', TRUE, CURRENT_TIMESTAMP),
('U002', 21, 'female', 'beginner', TRUE, CURRENT_TIMESTAMP),
('U003', 22, 'male', 'advanced', TRUE, CURRENT_TIMESTAMP),
('U004', 19, 'female', 'intermediate', TRUE, CURRENT_TIMESTAMP),
('U005', 23, 'other', 'beginner', TRUE, CURRENT_TIMESTAMP),
('U006', 24, 'male', 'advanced', TRUE, CURRENT_TIMESTAMP);

INSERT INTO player (
    user_id,
    nickname
)
VALUES
(1, 'player_alpha'),
(2, 'player_beta'),
(3, 'player_gamma'),
(4, 'player_delta'),
(5, 'player_epsilon'),
(6, 'player_zeta');

INSERT INTO episode (
    episode_code,
    name
)
VALUES
('E1', 'Knee Deep in the Dead'),
('E2', 'The Shores of Hell'),
('E3', 'Inferno');

INSERT INTO map (
    episode_id,
    map_code,
    name
)
VALUES
(1, 'MAP01', 'Hangar'),
(2, 'MAP02', 'Containment Area'),
(3, 'MAP03', 'Pandemonium');

INSERT INTO sector (
    map_id,
    sector_code,
    grid_x,
    grid_y
)
SELECT
    m.map_id,
    CONCAT('S', LPAD(gs::TEXT, 2, '0')) AS sector_code,
    ((gs - 1) % 5) * 250 AS grid_x,
    FLOOR((gs - 1) / 5) * 250 AS grid_y
FROM map m
CROSS JOIN generate_series(1, 25) AS gs;

INSERT INTO game (
    map_id,
    start_time,
    end_time,
    game_mode,
    difficulty
)
VALUES
(1, '2026-04-23 08:00:00', '2026-04-23 08:30:00', 'cooperative', 'medium'),
(2, '2026-04-24 09:00:00', '2026-04-24 09:35:00', 'cooperative', 'hard'),
(3, '2026-04-25 10:00:00', '2026-04-25 10:40:00', 'cooperative', 'medium');

INSERT INTO game_participant (
    game_id,
    player_id,
    role,
    final_score
)
SELECT
    g.game_id,
    p.player_id,
    'participant' AS role,
    FLOOR(random() * 10000)::INTEGER AS final_score
FROM game g
CROSS JOIN player p;
