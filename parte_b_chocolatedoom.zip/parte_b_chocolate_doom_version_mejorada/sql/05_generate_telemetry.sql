-- =========================================================
-- Parte B - Proyecto Chocolate Doom
-- Archivo: 05_generate_telemetry.sql
-- Objetivo: Generar telemetría sintética
-- Resultado esperado: 3 partidas x 6 jugadores x 1200 tics = 21600 filas
-- =========================================================

INSERT INTO telemetry_event (
    game_id,
    player_id,
    sector_id,
    tic,
    pos_x,
    pos_y,
    pos_z,
    angle,
    momentum_x,
    momentum_y,
    momentum_z,
    fov,
    health,
    armor,
    ammo
)
SELECT
    g.game_id,
    p.player_id,
    s.sector_id,
    t.tic,
    ROUND((random() * 1250)::NUMERIC, 4) AS pos_x,
    ROUND((random() * 1250)::NUMERIC, 4) AS pos_y,
    0 AS pos_z,
    ROUND((random() * 360)::NUMERIC, 4) AS angle,
    ROUND(((random() * 2) - 1)::NUMERIC, 4) AS momentum_x,
    ROUND(((random() * 2) - 1)::NUMERIC, 4) AS momentum_y,
    0 AS momentum_z,
    90 AS fov,
    GREATEST(0, 100 - FLOOR(t.tic / 100)::INTEGER + FLOOR(random() * 5)::INTEGER) AS health,
    FLOOR(random() * 100)::INTEGER AS armor,
    FLOOR(random() * 80)::INTEGER AS ammo
FROM game g
JOIN game_participant gp 
    ON gp.game_id = g.game_id
JOIN player p 
    ON p.player_id = gp.player_id
JOIN generate_series(1, 1200) AS t(tic) 
    ON TRUE
JOIN sector s 
    ON s.map_id = g.map_id
   AND s.sector_code = CONCAT(
        'S',
        LPAD(((((t.tic + p.player_id)::INTEGER % 25) + 1)::TEXT), 2, '0')
   )
ON CONFLICT (game_id, player_id, tic) DO NOTHING;
