CREATE INDEX IF NOT EXISTS idx_telemetry_game_player_tic ON telemetry_event (game_id, player_id, tic);
CREATE INDEX IF NOT EXISTS idx_telemetry_event_timestamp ON telemetry_event (event_timestamp);
CREATE INDEX IF NOT EXISTS idx_telemetry_sector ON telemetry_event (sector_id);
CREATE INDEX IF NOT EXISTS idx_game_source_session ON game (source_session_id);
CREATE INDEX IF NOT EXISTS idx_game_source_file ON game (source_file);
CREATE INDEX IF NOT EXISTS idx_sector_map_code ON sector (map_id, sector_code);
CREATE INDEX IF NOT EXISTS idx_c_te_game_tic_sector_player ON telemetry_event (game_id, tic, sector_id, player_id);
