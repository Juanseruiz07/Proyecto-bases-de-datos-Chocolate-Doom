DROP MATERIALIZED VIEW IF EXISTS mv_player_trajectory_distance;
DROP VIEW IF EXISTS v_sector_hotspots;
DROP VIEW IF EXISTS v_player_session_summary;

CREATE VIEW v_player_session_summary AS
SELECT g.game_id, g.source_session_id, g.source_file, e.episode_code, m.map_code, p.player_id, p.nickname, MIN(te.event_timestamp) AS first_event_time, MAX(te.event_timestamp) AS last_event_time, COUNT(te.telemetry_id) AS telemetry_events, COUNT(DISTINCT te.tic) AS tics_recorded, ROUND(AVG(te.health)::NUMERIC, 2) AS avg_health, ROUND(AVG(te.armor)::NUMERIC, 2) AS avg_armor, ROUND(AVG(te.ammo)::NUMERIC, 2) AS avg_ammo
FROM telemetry_event te
JOIN game g ON g.game_id = te.game_id
JOIN map m ON m.map_id = g.map_id
JOIN episode e ON e.episode_id = m.episode_id
JOIN player p ON p.player_id = te.player_id
GROUP BY g.game_id, g.source_session_id, g.source_file, e.episode_code, m.map_code, p.player_id, p.nickname;

CREATE VIEW v_sector_hotspots AS
SELECT e.episode_code, m.map_code, s.sector_id, s.sector_code, s.grid_x, s.grid_y, COUNT(te.telemetry_id) AS visits, COUNT(DISTINCT te.game_id) AS sessions_count, ROUND(AVG(te.health)::NUMERIC, 2) AS avg_health_in_sector
FROM telemetry_event te
JOIN sector s ON s.sector_id = te.sector_id
JOIN map m ON m.map_id = s.map_id
JOIN episode e ON e.episode_id = m.episode_id
GROUP BY e.episode_code, m.map_code, s.sector_id, s.sector_code, s.grid_x, s.grid_y;

CREATE MATERIALIZED VIEW mv_player_trajectory_distance AS
WITH ordered_points AS (
    SELECT te.game_id, te.player_id, te.tic, te.event_timestamp, te.pos_x, te.pos_y, te.pos_z, LAG(te.pos_x) OVER (PARTITION BY te.game_id, te.player_id ORDER BY te.tic) AS prev_x, LAG(te.pos_y) OVER (PARTITION BY te.game_id, te.player_id ORDER BY te.tic) AS prev_y, LAG(te.pos_z) OVER (PARTITION BY te.game_id, te.player_id ORDER BY te.tic) AS prev_z
    FROM telemetry_event te
)
SELECT op.game_id, g.source_session_id, g.source_file, e.episode_code, m.map_code, op.player_id, p.nickname, COUNT(*) AS telemetry_events, MIN(op.event_timestamp) AS first_event_time, MAX(op.event_timestamp) AS last_event_time, ROUND(SUM(CASE WHEN prev_x IS NULL THEN 0 ELSE SQRT(POWER(pos_x - prev_x, 2) + POWER(pos_y - prev_y, 2) + POWER(pos_z - prev_z, 2)) END)::NUMERIC, 2) AS trajectory_distance, ROUND((SUM(CASE WHEN prev_x IS NULL THEN 0 ELSE SQRT(POWER(pos_x - prev_x, 2) + POWER(pos_y - prev_y, 2) + POWER(pos_z - prev_z, 2)) END) / NULLIF(EXTRACT(EPOCH FROM (MAX(op.event_timestamp) - MIN(op.event_timestamp))), 0))::NUMERIC, 4) AS avg_speed_units_per_second
FROM ordered_points op
JOIN game g ON g.game_id = op.game_id
JOIN map m ON m.map_id = g.map_id
JOIN episode e ON e.episode_id = m.episode_id
JOIN player p ON p.player_id = op.player_id
GROUP BY op.game_id, g.source_session_id, g.source_file, e.episode_code, m.map_code, op.player_id, p.nickname;

CREATE INDEX IF NOT EXISTS idx_mv_player_trajectory_player ON mv_player_trajectory_distance (player_id, game_id);
CREATE INDEX IF NOT EXISTS idx_mv_player_trajectory_episode_map ON mv_player_trajectory_distance (episode_code, map_code);

SELECT * FROM v_player_session_summary ORDER BY game_id, nickname FETCH FIRST 10 ROWS ONLY;
SELECT * FROM v_sector_hotspots ORDER BY visits DESC FETCH FIRST 10 ROWS ONLY;
SELECT * FROM mv_player_trajectory_distance ORDER BY trajectory_distance DESC FETCH FIRST 10 ROWS ONLY;
