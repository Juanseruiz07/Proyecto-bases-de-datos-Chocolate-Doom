TRUNCATE TABLE staging_real_telemetry_raw;

\copy staging_real_telemetry_raw (source_file_raw, player_nickname_raw, source_session_id_raw, session_start_raw, episode_code_raw, map_code_raw, event_timestamp_raw, tic_raw, pos_x_raw, pos_y_raw, pos_z_raw, angle_raw, momentum_x_raw, momentum_y_raw, shield_raw, health_raw, ammo_raw, sector_code_raw, sector_grid_x_raw, sector_grid_y_raw) FROM 'data/doom_telemetry_staging_6_jugadores.csv' WITH (FORMAT csv, HEADER true, DELIMITER ',');
