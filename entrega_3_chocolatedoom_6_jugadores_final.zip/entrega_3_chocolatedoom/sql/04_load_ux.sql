INSERT INTO ux_instrument (name, version, description)
VALUES ('PENS', '1.0', 'Player Experience of Need Satisfaction instrument used to evaluate player experience in games')
ON CONFLICT (name, version) DO NOTHING;

INSERT INTO ux_item (instrument_id, item_code, question_text, dimension)
SELECT i.instrument_id, v.item_code, v.question_text, v.dimension
FROM ux_instrument i
CROSS JOIN (
    VALUES
        ('PENS01', 'I felt competent while playing the game.', 'competence'),
        ('PENS02', 'I felt free to make decisions during the game.', 'autonomy'),
        ('PENS03', 'I felt connected with other players.', 'relatedness'),
        ('PENS04', 'The game controls were easy to understand.', 'intuitive_controls'),
        ('PENS05', 'I felt immersed in the game environment.', 'immersion')
) AS v(item_code, question_text, dimension)
WHERE i.name = 'PENS' AND i.version = '1.0'
ON CONFLICT (instrument_id, item_code) DO NOTHING;

INSERT INTO ux_response (user_id, instrument_id, response_date, total_score)
SELECT ru.user_id, i.instrument_id, CURRENT_TIMESTAMP,
    CASE ru.anonymous_code
        WHEN 'U001' THEN 4
        WHEN 'U002' THEN 3
        WHEN 'U003' THEN 4
        WHEN 'U004' THEN 5
        WHEN 'U005' THEN 3
        WHEN 'U006' THEN 4
        ELSE 4
    END
FROM research_user ru
JOIN ux_instrument i ON i.name = 'PENS' AND i.version = '1.0';
