SELECT e.episode_code, m.map_code, COUNT(g.game_id) AS sessions_count, ROUND(AVG(EXTRACT(EPOCH FROM (COALESCE(g.end_time, g.start_time) - g.start_time)))::NUMERIC, 2) AS avg_duration_seconds, ROUND(AVG(EXTRACT(EPOCH FROM (COALESCE(g.end_time, g.start_time) - g.start_time)) / 60)::NUMERIC, 2) AS avg_duration_minutes
FROM game g
JOIN map m ON m.map_id = g.map_id
JOIN episode e ON e.episode_id = m.episode_id
GROUP BY e.episode_code, m.map_code
ORDER BY avg_duration_seconds DESC;

SELECT p1.nickname AS player_a, p2.nickname AS player_b, e.episode_code, m.map_code, COUNT(*) AS comparable_tics, ROUND(AVG(SQRT(POWER(te1.pos_x - te2.pos_x, 2) + POWER(te1.pos_y - te2.pos_y, 2) + POWER(te1.pos_z - te2.pos_z, 2)))::NUMERIC, 2) AS avg_distance
FROM telemetry_event te1
JOIN telemetry_event te2 ON te1.tic = te2.tic AND te1.player_id < te2.player_id
JOIN game g1 ON g1.game_id = te1.game_id
JOIN game g2 ON g2.game_id = te2.game_id AND g2.map_id = g1.map_id
JOIN map m ON m.map_id = g1.map_id
JOIN episode e ON e.episode_id = m.episode_id
JOIN player p1 ON p1.player_id = te1.player_id
JOIN player p2 ON p2.player_id = te2.player_id
GROUP BY p1.nickname, p2.nickname, e.episode_code, m.map_code
HAVING COUNT(*) >= 3
ORDER BY avg_distance ASC, comparable_tics DESC
FETCH FIRST 10 ROWS ONLY;

WITH ordered_points AS (
    SELECT te.game_id, te.player_id, te.tic, te.pos_x, te.pos_y, te.pos_z, LAG(te.pos_x) OVER (PARTITION BY te.game_id, te.player_id ORDER BY te.tic) AS prev_x, LAG(te.pos_y) OVER (PARTITION BY te.game_id, te.player_id ORDER BY te.tic) AS prev_y, LAG(te.pos_z) OVER (PARTITION BY te.game_id, te.player_id ORDER BY te.tic) AS prev_z
    FROM telemetry_event te
), session_distance AS (
    SELECT game_id, player_id, SUM(CASE WHEN prev_x IS NULL THEN 0 ELSE SQRT(POWER(pos_x - prev_x, 2) + POWER(pos_y - prev_y, 2) + POWER(pos_z - prev_z, 2)) END) AS trajectory_distance
    FROM ordered_points
    GROUP BY game_id, player_id
)
SELECT p.nickname, ROUND(MIN(sd.trajectory_distance)::NUMERIC, 2) AS shortest_trajectory, ROUND(MAX(sd.trajectory_distance)::NUMERIC, 2) AS longest_trajectory, ROUND(AVG(sd.trajectory_distance)::NUMERIC, 2) AS avg_trajectory
FROM session_distance sd
JOIN player p ON p.player_id = sd.player_id
GROUP BY p.nickname
ORDER BY avg_trajectory DESC;

WITH player_duration AS (
    SELECT te.player_id, COUNT(DISTINCT te.tic) AS tics_recorded, EXTRACT(EPOCH FROM (MAX(te.event_timestamp) - MIN(te.event_timestamp))) AS duration_seconds
    FROM telemetry_event te
    GROUP BY te.player_id
), avg_duration AS (
    SELECT AVG(duration_seconds) AS global_avg_duration FROM player_duration
)
SELECT p.nickname, pd.tics_recorded, ROUND(pd.duration_seconds::NUMERIC, 2) AS duration_seconds, ui.name AS ux_instrument, ur.total_score AS ux_score
FROM player_duration pd
JOIN avg_duration ad ON pd.duration_seconds >= ad.global_avg_duration
JOIN player p ON p.player_id = pd.player_id
JOIN research_user ru ON ru.user_id = p.user_id
LEFT JOIN ux_response ur ON ur.user_id = ru.user_id
LEFT JOIN ux_instrument ui ON ui.instrument_id = ur.instrument_id
ORDER BY pd.duration_seconds DESC;

WITH sector_counts AS (
    SELECT e.episode_code, m.map_code, s.sector_code, s.grid_x, s.grid_y, COUNT(*) AS visits, ROW_NUMBER() OVER (PARTITION BY e.episode_code, m.map_code ORDER BY COUNT(*) DESC) AS rn
    FROM telemetry_event te
    JOIN sector s ON s.sector_id = te.sector_id
    JOIN map m ON m.map_id = s.map_id
    JOIN episode e ON e.episode_id = m.episode_id
    GROUP BY e.episode_code, m.map_code, s.sector_code, s.grid_x, s.grid_y
)
SELECT episode_code, map_code, sector_code, grid_x, grid_y, visits
FROM sector_counts
WHERE rn = 1
ORDER BY episode_code, map_code;

SELECT p1.nickname AS player_a, p2.nickname AS player_b, e.episode_code, m.map_code, s.sector_code, COUNT(DISTINCT te1.tic) AS together_tics
FROM telemetry_event te1
JOIN telemetry_event te2 ON te1.tic = te2.tic AND te1.sector_id = te2.sector_id AND te1.player_id < te2.player_id
JOIN game g1 ON g1.game_id = te1.game_id
JOIN game g2 ON g2.game_id = te2.game_id AND g2.map_id = g1.map_id
JOIN player p1 ON p1.player_id = te1.player_id
JOIN player p2 ON p2.player_id = te2.player_id
JOIN sector s ON s.sector_id = te1.sector_id
JOIN map m ON m.map_id = s.map_id
JOIN episode e ON e.episode_id = m.episode_id
GROUP BY p1.nickname, p2.nickname, e.episode_code, m.map_code, s.sector_code
ORDER BY together_tics DESC
FETCH FIRST 20 ROWS ONLY;

WITH ordered_points AS (
    SELECT e.episode_id, e.episode_code, te.game_id, te.player_id, te.tic, te.pos_x, te.pos_y, te.pos_z, LAG(te.pos_x) OVER (PARTITION BY e.episode_id, te.game_id, te.player_id ORDER BY te.tic) AS prev_x, LAG(te.pos_y) OVER (PARTITION BY e.episode_id, te.game_id, te.player_id ORDER BY te.tic) AS prev_y, LAG(te.pos_z) OVER (PARTITION BY e.episode_id, te.game_id, te.player_id ORDER BY te.tic) AS prev_z
    FROM telemetry_event te
    JOIN game g ON g.game_id = te.game_id
    JOIN map m ON m.map_id = g.map_id
    JOIN episode e ON e.episode_id = m.episode_id
), trajectory_by_episode AS (
    SELECT episode_code, player_id, SUM(CASE WHEN prev_x IS NULL THEN 0 ELSE SQRT(POWER(pos_x - prev_x, 2) + POWER(pos_y - prev_y, 2) + POWER(pos_z - prev_z, 2)) END) AS distance
    FROM ordered_points
    GROUP BY episode_code, player_id
), ranked AS (
    SELECT *, RANK() OVER (PARTITION BY episode_code ORDER BY distance ASC) AS distance_rank
    FROM trajectory_by_episode
)
SELECT r.episode_code, p.nickname, ROUND(r.distance::NUMERIC, 2) AS shortest_distance, ROUND(AVG(ur.total_score)::NUMERIC, 2) AS avg_ux_score
FROM ranked r
JOIN player p ON p.player_id = r.player_id
JOIN research_user ru ON ru.user_id = p.user_id
LEFT JOIN ux_response ur ON ur.user_id = ru.user_id
WHERE r.distance_rank = 1
GROUP BY r.episode_code, p.nickname, r.distance
ORDER BY r.episode_code;

WITH ordered_points AS (
    SELECT te.player_id, te.game_id, te.tic, te.event_timestamp, te.pos_x, te.pos_y, te.pos_z, LAG(te.pos_x) OVER (PARTITION BY te.game_id, te.player_id ORDER BY te.tic) AS prev_x, LAG(te.pos_y) OVER (PARTITION BY te.game_id, te.player_id ORDER BY te.tic) AS prev_y, LAG(te.pos_z) OVER (PARTITION BY te.game_id, te.player_id ORDER BY te.tic) AS prev_z
    FROM telemetry_event te
), movement AS (
    SELECT player_id, game_id, SUM(CASE WHEN prev_x IS NULL THEN 0 ELSE SQRT(POWER(pos_x - prev_x, 2) + POWER(pos_y - prev_y, 2) + POWER(pos_z - prev_z, 2)) END) AS distance, EXTRACT(EPOCH FROM (MAX(event_timestamp) - MIN(event_timestamp))) AS duration_seconds
    FROM ordered_points
    GROUP BY player_id, game_id
)
SELECT p.nickname, ROUND(SUM(m.distance)::NUMERIC, 2) AS total_distance, ROUND(SUM(m.duration_seconds)::NUMERIC, 2) AS total_duration_seconds, ROUND((SUM(m.distance) / NULLIF(SUM(m.duration_seconds), 0))::NUMERIC, 4) AS avg_speed_units_per_second
FROM movement m
JOIN player p ON p.player_id = m.player_id
GROUP BY p.nickname
ORDER BY total_distance DESC;
