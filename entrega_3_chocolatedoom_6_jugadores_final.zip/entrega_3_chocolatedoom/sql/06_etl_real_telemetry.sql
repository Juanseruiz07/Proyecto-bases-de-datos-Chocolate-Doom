INSERT INTO etl_error_log (raw_id, error_message, raw_payload)
SELECT raw_id, 'Required field is empty', to_jsonb(r)
FROM staging_real_telemetry_raw r
WHERE trim(coalesce(source_file_raw, '')) = ''
   OR trim(coalesce(player_nickname_raw, '')) = ''
   OR trim(coalesce(source_session_id_raw, '')) = ''
   OR trim(coalesce(session_start_raw, '')) = ''
   OR trim(coalesce(episode_code_raw, '')) = ''
   OR trim(coalesce(map_code_raw, '')) = ''
   OR trim(coalesce(event_timestamp_raw, '')) = ''
   OR trim(coalesce(tic_raw, '')) = ''
   OR trim(coalesce(pos_x_raw, '')) = ''
   OR trim(coalesce(pos_y_raw, '')) = ''
   OR trim(coalesce(pos_z_raw, '')) = ''
   OR trim(coalesce(sector_code_raw, '')) = '';

INSERT INTO etl_error_log (raw_id, error_message, raw_payload)
SELECT r.raw_id, 'Player nickname in CSV does not exist in player table', to_jsonb(r)
FROM staging_real_telemetry_raw r
LEFT JOIN player p ON p.nickname = trim(r.player_nickname_raw)
WHERE p.player_id IS NULL;

INSERT INTO etl_error_log (raw_id, error_message, raw_payload)
SELECT raw_id, 'Invalid numeric format in real telemetry CSV', to_jsonb(r)
FROM staging_real_telemetry_raw r
WHERE trim(source_session_id_raw) !~ '^[0-9]+$'
   OR trim(tic_raw) !~ '^[0-9]+$'
   OR trim(pos_x_raw) !~ '^-?[0-9]+(\.[0-9]+)?$'
   OR trim(pos_y_raw) !~ '^-?[0-9]+(\.[0-9]+)?$'
   OR trim(pos_z_raw) !~ '^-?[0-9]+(\.[0-9]+)?$'
   OR trim(angle_raw) !~ '^-?[0-9]+(\.[0-9]+)?$'
   OR trim(momentum_x_raw) !~ '^-?[0-9]+(\.[0-9]+)?$'
   OR trim(momentum_y_raw) !~ '^-?[0-9]+(\.[0-9]+)?$'
   OR trim(shield_raw) !~ '^[0-9]+$'
   OR trim(health_raw) !~ '^[0-9]+$'
   OR trim(ammo_raw) !~ '^[0-9]+$'
   OR trim(sector_grid_x_raw) !~ '^-?[0-9]+$'
   OR trim(sector_grid_y_raw) !~ '^-?[0-9]+$';

INSERT INTO episode (episode_code, name)
SELECT DISTINCT trim(episode_code_raw), 'Episode ' || regexp_replace(trim(episode_code_raw), '^E', '')
FROM staging_real_telemetry_raw r
WHERE NOT EXISTS (SELECT 1 FROM etl_error_log e WHERE e.raw_id = r.raw_id)
ON CONFLICT (episode_code) DO NOTHING;

INSERT INTO map (episode_id, map_code, name)
SELECT DISTINCT e.episode_id, trim(r.map_code_raw), 'Map ' || regexp_replace(trim(r.map_code_raw), '^MAP', '')
FROM staging_real_telemetry_raw r
JOIN episode e ON e.episode_code = trim(r.episode_code_raw)
WHERE NOT EXISTS (SELECT 1 FROM etl_error_log er WHERE er.raw_id = r.raw_id)
ON CONFLICT (episode_id, map_code) DO NOTHING;

INSERT INTO sector (map_id, sector_code, grid_x, grid_y)
SELECT DISTINCT m.map_id, trim(r.sector_code_raw), trim(r.sector_grid_x_raw)::INTEGER, trim(r.sector_grid_y_raw)::INTEGER
FROM staging_real_telemetry_raw r
JOIN episode e ON e.episode_code = trim(r.episode_code_raw)
JOIN map m ON m.episode_id = e.episode_id AND m.map_code = trim(r.map_code_raw)
WHERE NOT EXISTS (SELECT 1 FROM etl_error_log er WHERE er.raw_id = r.raw_id)
ON CONFLICT (map_id, sector_code) DO NOTHING;

INSERT INTO game (map_id, source_session_id, source_file, start_time, end_time, game_mode, difficulty)
SELECT m.map_id, trim(r.source_session_id_raw)::INTEGER, MIN(trim(r.source_file_raw)), min(trim(r.session_start_raw)::TIMESTAMP), max(trim(r.event_timestamp_raw)::TIMESTAMP), 'single_player', 'medium'
FROM staging_real_telemetry_raw r
JOIN episode e ON e.episode_code = trim(r.episode_code_raw)
JOIN map m ON m.episode_id = e.episode_id AND m.map_code = trim(r.map_code_raw)
WHERE NOT EXISTS (SELECT 1 FROM etl_error_log er WHERE er.raw_id = r.raw_id)
GROUP BY m.map_id, trim(r.source_session_id_raw)::INTEGER
ON CONFLICT (source_session_id) DO NOTHING;

INSERT INTO game_participant (game_id, player_id, role, final_score)
SELECT DISTINCT g.game_id, p.player_id, 'single_player', 0
FROM staging_real_telemetry_raw r
JOIN game g ON g.source_session_id = trim(r.source_session_id_raw)::INTEGER
JOIN player p ON p.nickname = trim(r.player_nickname_raw)
WHERE NOT EXISTS (SELECT 1 FROM etl_error_log er WHERE er.raw_id = r.raw_id)
ON CONFLICT (game_id, player_id) DO NOTHING;

INSERT INTO telemetry_event (game_id, player_id, sector_id, event_timestamp, tic, pos_x, pos_y, pos_z, angle, momentum_x, momentum_y, momentum_z, fov, health, armor, ammo)
SELECT g.game_id, p.player_id, s.sector_id, trim(r.event_timestamp_raw)::TIMESTAMP, trim(r.tic_raw)::INTEGER, trim(r.pos_x_raw)::NUMERIC, trim(r.pos_y_raw)::NUMERIC, trim(r.pos_z_raw)::NUMERIC, trim(r.angle_raw)::NUMERIC, trim(r.momentum_x_raw)::NUMERIC, trim(r.momentum_y_raw)::NUMERIC, 0, NULL, trim(r.health_raw)::INTEGER, trim(r.shield_raw)::INTEGER, trim(r.ammo_raw)::INTEGER
FROM staging_real_telemetry_raw r
JOIN game g ON g.source_session_id = trim(r.source_session_id_raw)::INTEGER
JOIN player p ON p.nickname = trim(r.player_nickname_raw)
JOIN episode e ON e.episode_code = trim(r.episode_code_raw)
JOIN map m ON m.episode_id = e.episode_id AND m.map_code = trim(r.map_code_raw)
JOIN sector s ON s.map_id = m.map_id AND s.sector_code = trim(r.sector_code_raw)
WHERE NOT EXISTS (SELECT 1 FROM etl_error_log er WHERE er.raw_id = r.raw_id)
ON CONFLICT (game_id, player_id, tic) DO NOTHING;
