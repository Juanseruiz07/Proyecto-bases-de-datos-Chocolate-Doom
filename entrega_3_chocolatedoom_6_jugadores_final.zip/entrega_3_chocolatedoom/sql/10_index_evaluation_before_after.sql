DROP INDEX IF EXISTS idx_c_te_game_player_tic;
DROP INDEX IF EXISTS idx_c_te_game_tic_sector_player;
DROP INDEX IF EXISTS idx_c_te_sector;
DROP INDEX IF EXISTS idx_c_te_event_timestamp;
DROP INDEX IF EXISTS idx_c_gp_player_game;
DROP INDEX IF EXISTS idx_c_ux_response_user_instrument;
DROP INDEX IF EXISTS idx_c_sector_map_grid;

EXPLAIN (ANALYZE, BUFFERS)
SELECT te.game_id, te.player_id, te.tic, te.pos_x, te.pos_y, te.pos_z
FROM telemetry_event te
WHERE te.game_id = 1 AND te.player_id = 1
ORDER BY te.tic;

EXPLAIN (ANALYZE, BUFFERS)
SELECT s.sector_code, COUNT(*) AS visits
FROM telemetry_event te
JOIN sector s ON s.sector_id = te.sector_id
WHERE te.game_id = 1
GROUP BY s.sector_code
ORDER BY visits DESC;

EXPLAIN (ANALYZE, BUFFERS)
SELECT te.game_id, te.tic, te.sector_id, COUNT(*) AS players_in_sector
FROM telemetry_event te
GROUP BY te.game_id, te.tic, te.sector_id
HAVING COUNT(*) > 1
ORDER BY players_in_sector DESC;

CREATE INDEX IF NOT EXISTS idx_c_te_game_player_tic ON telemetry_event (game_id, player_id, tic);
CREATE INDEX IF NOT EXISTS idx_c_te_game_tic_sector_player ON telemetry_event (game_id, tic, sector_id, player_id);
CREATE INDEX IF NOT EXISTS idx_c_te_sector ON telemetry_event (sector_id);
CREATE INDEX IF NOT EXISTS idx_c_te_event_timestamp ON telemetry_event (event_timestamp);
CREATE INDEX IF NOT EXISTS idx_c_gp_player_game ON game_participant (player_id, game_id);
CREATE INDEX IF NOT EXISTS idx_c_ux_response_user_instrument ON ux_response (user_id, instrument_id);
CREATE INDEX IF NOT EXISTS idx_c_sector_map_grid ON sector (map_id, grid_x, grid_y);

ANALYZE telemetry_event;
ANALYZE game_participant;
ANALYZE ux_response;
ANALYZE sector;

EXPLAIN (ANALYZE, BUFFERS)
SELECT te.game_id, te.player_id, te.tic, te.pos_x, te.pos_y, te.pos_z
FROM telemetry_event te
WHERE te.game_id = 1 AND te.player_id = 1
ORDER BY te.tic;

EXPLAIN (ANALYZE, BUFFERS)
SELECT s.sector_code, COUNT(*) AS visits
FROM telemetry_event te
JOIN sector s ON s.sector_id = te.sector_id
WHERE te.game_id = 1
GROUP BY s.sector_code
ORDER BY visits DESC;

EXPLAIN (ANALYZE, BUFFERS)
SELECT te.game_id, te.tic, te.sector_id, COUNT(*) AS players_in_sector
FROM telemetry_event te
GROUP BY te.game_id, te.tic, te.sector_id
HAVING COUNT(*) > 1
ORDER BY players_in_sector DESC;
