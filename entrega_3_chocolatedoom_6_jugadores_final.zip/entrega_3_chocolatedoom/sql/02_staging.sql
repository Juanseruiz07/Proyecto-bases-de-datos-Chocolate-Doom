DROP TABLE IF EXISTS staging_real_telemetry_raw CASCADE;
DROP TABLE IF EXISTS etl_error_log CASCADE;

CREATE TABLE staging_real_telemetry_raw (
    raw_id BIGSERIAL PRIMARY KEY,
    source_file_raw TEXT,
    player_nickname_raw TEXT,
    source_session_id_raw TEXT,
    session_start_raw TEXT,
    episode_code_raw TEXT,
    map_code_raw TEXT,
    event_timestamp_raw TEXT,
    tic_raw TEXT,
    pos_x_raw TEXT,
    pos_y_raw TEXT,
    pos_z_raw TEXT,
    angle_raw TEXT,
    momentum_x_raw TEXT,
    momentum_y_raw TEXT,
    shield_raw TEXT,
    health_raw TEXT,
    ammo_raw TEXT,
    sector_code_raw TEXT,
    sector_grid_x_raw TEXT,
    sector_grid_y_raw TEXT,
    loaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE etl_error_log (
    error_id BIGSERIAL PRIMARY KEY,
    raw_id BIGINT,
    error_message TEXT NOT NULL,
    raw_payload JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
