SELECT 'Usuarios' AS entidad, COUNT(*) AS total FROM research_user
UNION ALL
SELECT 'Jugadores registrados', COUNT(*) FROM player
UNION ALL
SELECT 'Jugadores con telemetria real', COUNT(DISTINCT player_id) FROM telemetry_event
UNION ALL
SELECT 'Episodios reales', COUNT(*) FROM episode
UNION ALL
SELECT 'Mapas reales', COUNT(*) FROM map
UNION ALL
SELECT 'Sectores reales', COUNT(*) FROM sector
UNION ALL
SELECT 'Sesiones de juego reales', COUNT(*) FROM game
UNION ALL
SELECT 'Participaciones', COUNT(*) FROM game_participant
UNION ALL
SELECT 'Telemetria real', COUNT(*) FROM telemetry_event
UNION ALL
SELECT 'Respuestas UX', COUNT(*) FROM ux_response
UNION ALL
SELECT 'Errores ETL', COUNT(*) FROM etl_error_log;

SELECT p.nickname, COUNT(*) AS total_eventos, COUNT(DISTINCT g.game_id) AS sesiones, MIN(te.event_timestamp) AS primera_muestra, MAX(te.event_timestamp) AS ultima_muestra
FROM telemetry_event te
JOIN player p ON p.player_id = te.player_id
JOIN game g ON g.game_id = te.game_id
GROUP BY p.nickname
ORDER BY p.nickname;

SELECT e.episode_code, m.map_code, COUNT(*) AS total_eventos
FROM telemetry_event te
JOIN game g ON g.game_id = te.game_id
JOIN map m ON m.map_id = g.map_id
JOIN episode e ON e.episode_id = m.episode_id
GROUP BY e.episode_code, m.map_code
ORDER BY e.episode_code, m.map_code;

SELECT e.episode_code, m.map_code, s.sector_code, COUNT(*) AS visitas
FROM telemetry_event te
JOIN sector s ON s.sector_id = te.sector_id
JOIN map m ON m.map_id = s.map_id
JOIN episode e ON e.episode_id = m.episode_id
GROUP BY e.episode_code, m.map_code, s.sector_code
ORDER BY visitas DESC
FETCH FIRST 10 ROWS ONLY;

SELECT MIN(event_timestamp) AS primera_muestra, MAX(event_timestamp) AS ultima_muestra, COUNT(*) AS total_muestras
FROM telemetry_event;
