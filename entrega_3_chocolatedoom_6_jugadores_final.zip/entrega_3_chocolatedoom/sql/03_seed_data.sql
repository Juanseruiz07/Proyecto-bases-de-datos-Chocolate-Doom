INSERT INTO research_user (anonymous_code, age, gender, experience_level, consent_accepted, consent_date)
VALUES
    ('U001', 20, 'not_reported', 'intermediate', TRUE, CURRENT_TIMESTAMP),
    ('U002', 21, 'not_reported', 'beginner', TRUE, CURRENT_TIMESTAMP),
    ('U003', 22, 'not_reported', 'intermediate', TRUE, CURRENT_TIMESTAMP),
    ('U004', 23, 'not_reported', 'advanced', TRUE, CURRENT_TIMESTAMP),
    ('U005', 24, 'not_reported', 'beginner', TRUE, CURRENT_TIMESTAMP),
    ('U006', 21, 'not_reported', 'intermediate', TRUE, CURRENT_TIMESTAMP)
ON CONFLICT (anonymous_code) DO NOTHING;

INSERT INTO player (user_id, nickname, created_at)
SELECT ru.user_id, v.nickname, CURRENT_TIMESTAMP
FROM (
    VALUES
        ('U001', 'player_01'),
        ('U002', 'player_02'),
        ('U003', 'player_03'),
        ('U004', 'player_04'),
        ('U005', 'player_05'),
        ('U006', 'player_06')
) AS v(anonymous_code, nickname)
JOIN research_user ru ON ru.anonymous_code = v.anonymous_code
ON CONFLICT (user_id, nickname) DO NOTHING;
