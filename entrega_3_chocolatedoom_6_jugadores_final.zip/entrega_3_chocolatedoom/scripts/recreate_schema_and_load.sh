#!/usr/bin/env bash
set -e
DB_NAME=${1:-chocolate_doom}
psql -U postgres -d "$DB_NAME" -f sql/00_run_all.sql
