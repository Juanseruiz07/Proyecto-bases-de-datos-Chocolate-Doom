# Entrega 3 Chocolate Doom Telemetry & UX Database

## Contenido

- `docs/informe_entrega_3_chocolate_doom_6_jugadores.docx`: informe editable para agregar evidencias.
- `data/doom_telemetry_unificada.csv`: telemetria real consolidada con 6 jugadores.
- `data/doom_telemetry_staging_6_jugadores.csv`: archivo recomendado para importar a `staging_real_telemetry_raw`.
- `data/resumen_telemetria_6_jugadores.csv`: resumen por jugador.
- `sql/01_schema.sql` a `sql/11_views_materialized.sql`: scripts PostgreSQL sin comentarios, listos para ejecutar.
- `scripts/recreate_schema_and_load.sh`: mecanismo simple para recrear esquema y cargar datos.
- `Makefile`: comandos de carga, consultas, indices y vistas.

## Datos consolidados

- Eventos reales: 5686
- Jugadores reales: 6
- Sesiones reales: 50
- Jugadores: player_01, player_02, player_03, player_04, player_05, player_06

## Orden recomendado

```bash
psql -U postgres -d chocolate_doom -f sql/00_run_all.sql
psql -U postgres -d chocolate_doom -f sql/09_part_c_analytical_queries.sql
psql -U postgres -d chocolate_doom -f sql/10_index_evaluation_before_after.sql
```

En pgAdmin, importa `data/doom_telemetry_staging_6_jugadores.csv` sobre la tabla `staging_real_telemetry_raw` si no usas `psql`.
