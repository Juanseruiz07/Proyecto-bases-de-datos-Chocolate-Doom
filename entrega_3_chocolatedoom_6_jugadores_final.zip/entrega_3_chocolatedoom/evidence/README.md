Coloca aqui las capturas de pantalla de pgAdmin para:

1. Validacion de cantidades.
2. Resultado de consultas analiticas.
3. EXPLAIN ANALYZE antes de indices.
4. EXPLAIN ANALYZE despues de indices.
5. Vistas normales.
6. Vista materializada.
