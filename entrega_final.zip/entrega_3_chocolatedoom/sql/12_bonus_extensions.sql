DO $$
BEGIN
    EXECUTE 'CREATE EXTENSION IF NOT EXISTS pgcrypto';
EXCEPTION
    WHEN insufficient_privilege OR undefined_file THEN
        RAISE NOTICE 'pgcrypto extension could not be enabled in this environment';
END $$;

DO $$
BEGIN
    EXECUTE 'CREATE EXTENSION IF NOT EXISTS citext';
EXCEPTION
    WHEN insufficient_privilege OR undefined_file THEN
        RAISE NOTICE 'citext extension could not be enabled in this environment';
END $$;

DO $$
BEGIN
    EXECUTE 'CREATE EXTENSION IF NOT EXISTS "uuid-ossp"';
EXCEPTION
    WHEN insufficient_privilege OR undefined_file THEN
        RAISE NOTICE 'uuid-ossp extension could not be enabled in this environment';
END $$;

SELECT extname
FROM pg_extension
WHERE extname IN ('pgcrypto', 'citext', 'uuid-ossp')
ORDER BY extname;
