DROP TABLE IF EXISTS staging_professor_telemetry_raw CASCADE;
DROP TABLE IF EXISTS etl_error_log CASCADE;

CREATE TABLE staging_professor_telemetry_raw (
    raw_id BIGSERIAL PRIMARY KEY,
    event_timestamp_raw TEXT,
    tic_raw TEXT,
    pos_x_raw TEXT,
    pos_y_raw TEXT,
    pos_z_raw TEXT,
    angle_raw TEXT,
    momentum_x_raw TEXT,
    momentum_y_raw TEXT,
    raw_col9 TEXT,
    loaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE etl_error_log (
    error_id BIGSERIAL PRIMARY KEY,
    raw_id BIGINT,
    error_message TEXT NOT NULL,
    raw_payload JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
