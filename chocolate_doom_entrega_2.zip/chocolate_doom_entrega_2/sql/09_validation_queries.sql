SELECT COUNT(*) AS total_users FROM research_user;
SELECT COUNT(*) AS total_players FROM player;
SELECT COUNT(*) AS total_episodes FROM episode;
SELECT COUNT(*) AS total_maps FROM map;
SELECT COUNT(*) AS total_sectors FROM sector;
SELECT COUNT(*) AS total_games FROM game;
SELECT COUNT(*) AS total_participants FROM game_participant;
SELECT COUNT(*) AS total_staging_rows FROM staging_professor_telemetry_raw;
SELECT COUNT(*) AS total_etl_errors FROM etl_error_log;
SELECT COUNT(*) AS total_telemetry_events FROM telemetry_event;
SELECT COUNT(*) AS total_ux_instruments FROM ux_instrument;
SELECT COUNT(*) AS total_ux_items FROM ux_item;
SELECT COUNT(*) AS total_ux_responses FROM ux_response;

SELECT
    g.game_id,
    m.map_code,
    COUNT(te.telemetry_id) AS telemetry_events
FROM game g
JOIN map m ON m.map_id = g.map_id
LEFT JOIN telemetry_event te ON te.game_id = g.game_id
GROUP BY g.game_id, m.map_code
ORDER BY g.game_id;

SELECT
    p.nickname,
    COUNT(te.telemetry_id) AS telemetry_events
FROM player p
LEFT JOIN telemetry_event te ON te.player_id = p.player_id
GROUP BY p.nickname
ORDER BY telemetry_events DESC;
