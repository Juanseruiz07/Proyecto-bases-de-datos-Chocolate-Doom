\echo 'Parte B Chocolate Doom - ejecucion completa'
\i sql/01_schema.sql
\i sql/02_staging.sql
\i sql/03_seed_data.sql
\i sql/04_load_ux.sql
\i sql/05_load_professor_tsv.sql
\i sql/06_etl_professor_tsv.sql
\i sql/07_generate_telemetry_from_tsv.sql
\i sql/08_indexes.sql
\i sql/09_validation_queries.sql
