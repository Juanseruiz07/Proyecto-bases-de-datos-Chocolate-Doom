-- Execute this script from the project root with psql.
-- The file has no header and contains 9 tab-separated columns.
TRUNCATE TABLE staging_professor_telemetry_raw;

\copy staging_professor_telemetry_raw (event_timestamp_raw, tic_raw, pos_x_raw, pos_y_raw, pos_z_raw, angle_raw, momentum_x_raw, momentum_y_raw, raw_col9) FROM 'data/andres.tsv' WITH (FORMAT csv, DELIMITER E'\t', HEADER false);
