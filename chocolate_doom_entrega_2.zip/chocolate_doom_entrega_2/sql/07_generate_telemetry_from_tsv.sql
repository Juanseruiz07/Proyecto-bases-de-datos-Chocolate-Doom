-- Synthetic expansion based on the real professor TSV.
-- 275 TSV rows x 3 games x 6 players x 5 cycles = 24750 target rows.
INSERT INTO telemetry_event (
    game_id, player_id, sector_id, tic, pos_x, pos_y, pos_z, angle,
    momentum_x, momentum_y, momentum_z, fov, health, armor, ammo
)
SELECT
    g.game_id,
    p.player_id,
    s.sector_id,
    (trim(r.tic_raw)::INTEGER + (cycle_id * 100000) + (p.player_id * 10000)) AS tic,
    (trim(r.pos_x_raw)::NUMERIC + ((p.player_id - 1) * 5)) AS pos_x,
    (trim(r.pos_y_raw)::NUMERIC + ((cycle_id - 1) * 3)) AS pos_y,
    trim(r.pos_z_raw)::NUMERIC AS pos_z,
    trim(r.angle_raw)::NUMERIC AS angle,
    trim(r.momentum_x_raw)::NUMERIC AS momentum_x,
    trim(r.momentum_y_raw)::NUMERIC AS momentum_y,
    0 AS momentum_z,
    90 AS fov,
    GREATEST(0, 100 - cycle_id - FLOOR(random() * 10)::INTEGER) AS health,
    FLOOR(random() * 100)::INTEGER AS armor,
    FLOOR(random() * 80)::INTEGER AS ammo
FROM staging_professor_telemetry_raw r
CROSS JOIN game g
CROSS JOIN player p
CROSS JOIN generate_series(1, 5) AS cycle_id
JOIN sector s
    ON s.map_id = g.map_id
   AND s.grid_x = (floor((trim(r.pos_x_raw)::NUMERIC + ((p.player_id - 1) * 5)) / 250) * 250)
   AND s.grid_y = (floor((trim(r.pos_y_raw)::NUMERIC + ((cycle_id - 1) * 3)) / 250) * 250)
WHERE NOT EXISTS (
    SELECT 1
    FROM etl_error_log e
    WHERE e.raw_id = r.raw_id
)
ON CONFLICT (game_id, player_id, tic) DO NOTHING;
