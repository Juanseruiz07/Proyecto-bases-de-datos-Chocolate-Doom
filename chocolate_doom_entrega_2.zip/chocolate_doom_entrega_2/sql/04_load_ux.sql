INSERT INTO ux_instrument (name, version, description) VALUES
('PENS', '1.0', 'Player Experience of Need Satisfaction instrument used to evaluate player experience in games');

INSERT INTO ux_item (instrument_id, item_code, question_text, dimension) VALUES
(1, 'PENS01', 'I felt competent while playing the game.', 'competence'),
(1, 'PENS02', 'I felt free to make decisions during the game.', 'autonomy'),
(1, 'PENS03', 'I felt connected with other players.', 'relatedness'),
(1, 'PENS04', 'The game controls were easy to understand.', 'intuitive_controls'),
(1, 'PENS05', 'I felt immersed in the game environment.', 'immersion');

-- The corrected model stores the consolidated UX result in UX_RESPONSE.total_score.
INSERT INTO ux_response (user_id, instrument_id, response_date, total_score) VALUES
(1, 1, CURRENT_TIMESTAMP, 4.20),
(2, 1, CURRENT_TIMESTAMP, 3.60),
(3, 1, CURRENT_TIMESTAMP, 4.80),
(4, 1, CURRENT_TIMESTAMP, 4.00),
(5, 1, CURRENT_TIMESTAMP, 3.20),
(6, 1, CURRENT_TIMESTAMP, 4.60);
