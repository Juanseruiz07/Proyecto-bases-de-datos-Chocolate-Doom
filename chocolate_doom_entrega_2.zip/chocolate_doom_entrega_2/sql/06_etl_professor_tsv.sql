-- Basic validation of the professor TSV before transformation.
INSERT INTO etl_error_log (raw_id, error_message, raw_payload)
SELECT raw_id, 'Required field is empty', to_jsonb(r)
FROM staging_professor_telemetry_raw r
WHERE trim(coalesce(event_timestamp_raw, '')) = ''
   OR trim(coalesce(tic_raw, '')) = ''
   OR trim(coalesce(pos_x_raw, '')) = ''
   OR trim(coalesce(pos_y_raw, '')) = ''
   OR trim(coalesce(pos_z_raw, '')) = '';

INSERT INTO etl_error_log (raw_id, error_message, raw_payload)
SELECT raw_id, 'Invalid numeric format in professor TSV', to_jsonb(r)
FROM staging_professor_telemetry_raw r
WHERE trim(tic_raw) !~ '^-?[0-9]+$'
   OR trim(pos_x_raw) !~ '^-?[0-9]+(\.[0-9]+)?$'
   OR trim(pos_y_raw) !~ '^-?[0-9]+(\.[0-9]+)?$'
   OR trim(pos_z_raw) !~ '^-?[0-9]+(\.[0-9]+)?$'
   OR trim(angle_raw) !~ '^-?[0-9]+(\.[0-9]+)?$'
   OR trim(momentum_x_raw) !~ '^-?[0-9]+(\.[0-9]+)?$'
   OR trim(momentum_y_raw) !~ '^-?[0-9]+(\.[0-9]+)?$';

-- Load one direct trajectory from the TSV into game 1 and player 1.
INSERT INTO telemetry_event (
    game_id, player_id, sector_id, tic, pos_x, pos_y, pos_z, angle,
    momentum_x, momentum_y, momentum_z, fov, health, armor, ammo
)
SELECT
    1 AS game_id,
    1 AS player_id,
    s.sector_id,
    trim(r.tic_raw)::INTEGER AS tic,
    trim(r.pos_x_raw)::NUMERIC AS pos_x,
    trim(r.pos_y_raw)::NUMERIC AS pos_y,
    trim(r.pos_z_raw)::NUMERIC AS pos_z,
    trim(r.angle_raw)::NUMERIC AS angle,
    trim(r.momentum_x_raw)::NUMERIC AS momentum_x,
    trim(r.momentum_y_raw)::NUMERIC AS momentum_y,
    0 AS momentum_z,
    90 AS fov,
    100 AS health,
    0 AS armor,
    50 AS ammo
FROM staging_professor_telemetry_raw r
JOIN sector s
    ON s.map_id = 1
   AND s.grid_x = (floor(trim(r.pos_x_raw)::NUMERIC / 250) * 250)
   AND s.grid_y = (floor(trim(r.pos_y_raw)::NUMERIC / 250) * 250)
WHERE NOT EXISTS (
    SELECT 1
    FROM etl_error_log e
    WHERE e.raw_id = r.raw_id
)
ON CONFLICT (game_id, player_id, tic) DO NOTHING;
