INSERT INTO research_user (anonymous_code, age, gender, experience_level, consent_accepted, consent_date) VALUES
('U001', 20, 'male', 'intermediate', TRUE, CURRENT_TIMESTAMP),
('U002', 21, 'female', 'beginner', TRUE, CURRENT_TIMESTAMP),
('U003', 22, 'male', 'advanced', TRUE, CURRENT_TIMESTAMP),
('U004', 19, 'female', 'intermediate', TRUE, CURRENT_TIMESTAMP),
('U005', 23, 'other', 'beginner', TRUE, CURRENT_TIMESTAMP),
('U006', 24, 'male', 'advanced', TRUE, CURRENT_TIMESTAMP);

INSERT INTO player (user_id, nickname) VALUES
(1, 'player_alpha'),
(2, 'player_beta'),
(3, 'player_gamma'),
(4, 'player_delta'),
(5, 'player_epsilon'),
(6, 'player_zeta');

INSERT INTO episode (episode_code, name) VALUES
('E1', 'Knee Deep in the Dead'),
('E2', 'The Shores of Hell'),
('E3', 'Inferno');

INSERT INTO map (episode_id, map_code, name) VALUES
(1, 'MAP01', 'Hangar'),
(2, 'MAP02', 'Containment Area'),
(3, 'MAP03', 'Pandemonium');

-- Sectors are generated as 250 x 250 grid cells. The range covers the professor TSV coordinates.
INSERT INTO sector (map_id, sector_code, grid_x, grid_y)
SELECT
    m.map_id,
    CONCAT('GX', gx::TEXT, '_GY', gy::TEXT) AS sector_code,
    gx::NUMERIC AS grid_x,
    gy::NUMERIC AS grid_y
FROM map m
CROSS JOIN generate_series(-750, 1250, 250) AS gx
CROSS JOIN generate_series(-250, 2500, 250) AS gy;

INSERT INTO game (map_id, start_time, end_time, game_mode, difficulty) VALUES
(1, '2025-11-21 08:32:56', '2025-11-21 08:38:15', 'cooperative', 'medium'),
(2, '2025-11-21 09:00:00', '2025-11-21 09:20:00', 'cooperative', 'hard'),
(3, '2025-11-21 10:00:00', '2025-11-21 10:25:00', 'cooperative', 'medium');

INSERT INTO game_participant (game_id, player_id, role, final_score)
SELECT
    g.game_id,
    p.player_id,
    'participant' AS role,
    FLOOR(random() * 10000)::INTEGER AS final_score
FROM game g
CROSS JOIN player p;
