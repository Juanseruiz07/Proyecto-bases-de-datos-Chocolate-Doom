CREATE INDEX IF NOT EXISTS idx_telemetry_game_player_tic
ON telemetry_event (game_id, player_id, tic);

CREATE INDEX IF NOT EXISTS idx_telemetry_sector
ON telemetry_event (sector_id);

CREATE INDEX IF NOT EXISTS idx_telemetry_game_tic
ON telemetry_event (game_id, tic);

CREATE INDEX IF NOT EXISTS idx_game_participant_player_game
ON game_participant (player_id, game_id);

CREATE INDEX IF NOT EXISTS idx_map_episode_code
ON map (episode_id, map_code);

CREATE INDEX IF NOT EXISTS idx_sector_map_grid
ON sector (map_id, grid_x, grid_y);

CREATE INDEX IF NOT EXISTS idx_ux_response_user_instrument
ON ux_response (user_id, instrument_id);
