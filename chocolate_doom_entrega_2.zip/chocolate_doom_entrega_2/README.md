# Chocolate Doom Telemetry & UX Database - Entrega 2

Esta carpeta contiene la segunda entrega del proyecto Chocolate Doom Telemetry & UX Database. Incluye el informe en PDF, el diagrama ER, los scripts SQL, el archivo TSV de entrada, la carga a staging, el proceso ETL, la carga del instrumento UX y las consultas de validación.

## Estructura

```text
chocolate_doom_entrega_2/
├── README.md
├── data/
│   └── andres.tsv
├── docs/
│   └── informe_entrega_2_chocolate_doom.pdf
├── img/
│   └── diagrama_er.png
└── sql/
    ├── 00_run_all.sql
    ├── 01_schema.sql
    ├── 02_staging.sql
    ├── 03_seed_data.sql
    ├── 04_load_ux.sql
    ├── 05_load_professor_tsv.sql
    ├── 06_etl_professor_tsv.sql
    ├── 07_generate_telemetry_from_tsv.sql
    ├── 08_indexes.sql
    └── 09_validation_queries.sql
```

## Ejecución

Desde `psql`, ubicado en la raíz del proyecto:

```sql
\i sql/00_run_all.sql
```

## Contenido principal

- `docs/informe_entrega_2_chocolate_doom.pdf`: informe de la entrega.
- `img/diagrama_er.png`: diagrama ER del modelo.
- `data/andres.tsv`: archivo TSV usado como insumo de telemetría.
- `01_schema.sql`: crea el esquema relacional en PostgreSQL.
- `02_staging.sql`: crea la tabla de staging y la tabla de errores ETL.
- `03_seed_data.sql`: inserta usuarios, jugadores, episodios, mapas, sectores, partidas y participantes.
- `04_load_ux.sql`: carga el instrumento UX PENS y respuestas consolidadas.
- `05_load_professor_tsv.sql`: carga el archivo `andres.tsv` a staging.
- `06_etl_professor_tsv.sql`: transforma registros válidos desde staging hacia las tablas principales.
- `07_generate_telemetry_from_tsv.sql`: genera más de 20.000 registros de telemetría usando el TSV como base.
- `08_indexes.sql`: crea índices útiles para consultas frecuentes.
- `09_validation_queries.sql`: valida los datos cargados.

## Fuente TSV

El archivo `data/andres.tsv` se usa como insumo de telemetría. La tabla de staging recibe 9 columnas sin encabezado:

1. timestamp del evento
2. tic
3. pos_x
4. pos_y
5. pos_z
6. angle
7. momentum_x
8. momentum_y
9. columna adicional cruda

## Resultado esperado

La carga genera:

- 6 usuarios
- 6 jugadores
- 3 episodios
- 3 mapas
- 324 sectores
- 3 partidas
- 18 participaciones
- 275 filas del TSV en staging
- Más de 20.000 eventos de telemetría
- Instrumento UX PENS cargado
- Respuestas UX consolidadas en `UX_RESPONSE.total_score`
